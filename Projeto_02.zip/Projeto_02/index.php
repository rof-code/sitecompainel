<?php include('config.php');?>
<?php Site::updateUsuarioOnline();?>
<?php Site::contador();?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <link href="<?php echo INCLUDE_PATH; ?>css/estilo.css" type="text/css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/fontawesome.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/brands.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/all.min.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/regular.min.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/svg-with-js.min.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/v4-shims.min.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/solid.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/fontawesome.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;1,100;1,300;1,400;1,500&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Gotu&display=swap" rel="stylesheet">
        <meta charset="UTF-8">
        <meta name="author" content="Rodolfo Augusto">
        <meta name="keywords" content="Criaçao de sites, Desenvolvimento Web, FullStack Developer, fullstack, web developer, HTML, CSS, JavaScript, Criação de Site Valinhos, Valinhos Site, Marketing Valinhos, Desenvolvimento de APPS, Aplicativos React">
        <meta name="description" content="DevCodar - Systems Development">
        <link rel="icon" href="<?php echo INCLUDE_PATH; ?>favicon.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>DevCodar Development</title>
    </head>
    <body>         
    <base base="<?php echo INCLUDE_PATH; ?>" />
        <?php
            $url = isset($_GET['url']) ? $_GET['url']: 'home';
            switch($url){
                case 'depoimentos':
                    echo '<target target="depoimentos" />';
                    break; 
                case 'servicos':
                    echo '<target target="servicos" />';
                    break; 
            }
        ?>
        <div class="sucesso">Enviado com Sucesso!</div><!-- div sucesso-->
        <div class="overlay-loading">
            <img src="<?php echo INCLUDE_PATH; ?>images/ajax-loader.gif">
        </div><!--OverlayLoading-->
        <header>
                <a href="<?php echo INCLUDE_PATH; ?>"><img class="logo" src="images/logopronta.png" title="DevCodar Desenvolvimento de Sistemas" alt="logo DevCodar Desenvolvimento de Sistemas"></a>
                <nav class="nav__links">
                    <ul>
                        <li><a href="<?php echo INCLUDE_PATH; ?>">Home</a></li>
                        <li><a href="<?php echo INCLUDE_PATH; ?>depoimentos">Depoimentos</a></li>
                        <li><a href="<?php echo INCLUDE_PATH; ?>servicos">Serviços</a></li>
                    </ul>
                </nav>
                <a class="cta" realtime="contato" href="<?php echo INCLUDE_PATH; ?>contato"><button>Contato</button></a>
                <nav class="mobile">
                    <div class="btn-mobile">
                        <i class="fas fa-bars"></i>
                    </div>
                    <ul>
                        <li><a href="<?php echo INCLUDE_PATH; ?>">Home</a></li>
                        <li><a href="<?php echo INCLUDE_PATH; ?>depoimentos">Depoimentos</a></li>
                        <li><a href="<?php echo INCLUDE_PATH; ?>servicos">Serviços</a></li>
                        <li><a href="<?php echo INCLUDE_PATH; ?>contato">Contato</a></li>
                    </ul>   
                </nav>
        </header>
        <div class="container-principal">
        <!--FIM DO HEADER -->
        <?php 
            if(file_exists('pages/'.$url.'.php')){
                include('pages/'.$url.'.php');
            }else{
                // Podemos colocar uma pagina como error
                if($url != 'depoimentos' && $url != 'servicos'){ 
                    $pagina404 = true;
                    include('pages/404.php');
                }else{
                    include('pages/home.php');
                }
            } 
        ?> 

        </div><!-- Container-Principal--> 
        <footer <?php if(isset($pagina404) && $pagina404 == true) echo 'class="fixed"'; ?>>
            <div class="center">
                <p>Criado por: Rodolfo Augusto | Todos os direitos reservados.</p>
            </div><!-- DIV CENTER -->
        </footer>
        <script src="<?php echo INCLUDE_PATH; ?>js/jquery.js"></script>
        <script src="<?php echo INCLUDE_PATH; ?>js/constants.js"></script>
        <script src='https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyDHPNQxozOzQSZ-djvWGOBUsHkBUoT_qH4'></script>  
        <script src="<?php echo INCLUDE_PATH; ?>js/maps.js"></script>
        <script src="<?php echo INCLUDE_PATH; ?>js/scripts.js"></script>
        <?php 
            if($url == 'home' || $url == ''){
        ?>
        <script src="<?php echo INCLUDE_PATH; ?>js/sliders.js"></script>
        <?php } ?>
        <?php
            if($url == 'contato'){
        ?>           
        <?php } ?>
        <script src="<?php echo INCLUDE_PATH; ?>js/forms.js"></script>
        <script src="<?php echo INCLUDE_PATH; ?>js/boxes.js"></script>
    </body>
</html>