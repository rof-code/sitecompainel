<?php
    include('../config.php');
    $data = [];
    $assunto = 'Nova mensagem do Site!';
    $corpo = '';
    foreach($_POST as $key => $value){
        $corpo.=ucfirst($key).": ".$value;
        $corpo.="<hr>";
    }
    $info = array('assunto'=>$assunto, 'corpo'=>$corpo);
    $mail = new Email('smtp.gmail.com','rofgbr@gmail.com','ahsok@1234','Rodolfo Augusto');
    $mail->addAdress('rof.bra@gmail.com','Rodolfo');
    $mail->formatarEmail($info);
    if($mail->enviarEmail()){
      $data['sucesso']= true;
    }else{
      $data['erro'] = true;
    }

    $data['retorno'] = 'sucesso';

    die(json_encode($data));


?>