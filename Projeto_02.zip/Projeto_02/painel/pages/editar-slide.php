<?php
    if(isset($_GET['id'])){
        $id = (int)$_GET['id'];
        $slide = Painel::select('tb_site.slides','id = ?',array($id));
    }else{
        Painel::alert('erro','Você precisa passar o parametro ID!');
        die();
    }
?>
<div class="box-content">
    <h2><i class="fa fa-pen"></i> Editar Slide</h2>
    
    <form method="post" enctype="multipart/form-data">

        <?php 
            if(isset($_POST['action'])){
                //Eviei o meu formulário
                $nome = $_POST['nome'];
                $imagem = $_FILES['imagem'];
                $imagem_atual = $_POST['imagem_atual'];
                if($imagem['name'] != ''){
                    //Existe upload da imagem!
                    if(Painel::imagemValida($imagem)){
                        Painel::deleteFiles($imagem_atual);     
                        $imagem = Painel::uploadFile($imagem);
                        $arr = ['nome'=>$nome,'slide'=>$imagem,'id'=>$id,'nome_tabela'=>'tb_site.slides'];
                        Painel::update($arr);
                        $slide = Painel::select('tb_site.slides','id = ?',array($id));
                        Painel::alert('sucesso','Atualizado com sucesso!');
                    }else{
                        Painel::alert('erro','O formato não é válido!');
                    }

                }else{
                    $imagem = $imagem_atual;
                    $arr = ['nome'=>$nome,'slide'=>$imagem,'id'=>$id,'nome_tabela'=>'tb_site.slides'];
                    Painel::update($arr);
                    $slide = Painel::select('tb_site.slides','id = ?',array($id));
                    Painel::alert('sucesso','Atualizado com sucesso!');
                }
               
            }
        ?>
        <div class="form-group">
            <label>Nome:</label>
            <input type="text" name="nome" required value="<?php echo $slide['nome']; ?>">
        </div><!--From-Group-->

        <div class="form-group">
            <label>Imagem</label>
            <input type="file" name="imagem">
            <input type="hidden" name="imagem_atual" value="<?php echo $slide['slide']; ?>">
        </div><!--Form-Group-->

        <div class="form-group">
            <input type="submit" name="action" value="Atualizar">

        </div><!--Form-Group-->
    </form>


</div><!--Box-Content-->