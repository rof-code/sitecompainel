<div class="box-content">
    <h2><i class="fa fa-pen"></i> Editar Usuário</h2>
    
    <form method="post" enctype="multipart/form-data">

        <?php 
            if(isset($_POST['action'])){
                //Eviei o meu formulário
                $nome = $_POST['nome'];
                $senha = $_POST['password'];
                $imagem = $_FILES['imagem'];
                $imagem_atual = $_POST['imagem_atual'];
                $usuario = new Usuario();
                if($imagem['name'] != ''){
                    //Existe upload da imagem!
                    if(Painel::imagemValida($imagem)){
                        Painel::deleteFiles($imagem_atual);     
                        $imagem = Painel::uploadFile($imagem);
                        if($usuario->atualizarUsuario($nome,$senha,$imagem)){
                            $_SESSION['img'] = $imagem;
                            Painel::alert('sucesso','Dados atualizados com sucesso!');
                        }else{
                            Painel::alert('erro','Ocorreu um erro ao atualizar os dados!'); 
                        }
                    }else{
                        Painel::alert('erro','O formato não é válido!');
                    }

                }else{
                    $imagem = $imagem_atual;
                    
                    if($usuario->atualizarUsuario($nome,$senha,$imagem)){
                        Painel::alert('sucesso','Dados atualizados com sucesso!');
                    }else{
                        Painel::alert('erro','Ocorreu um erro ao atualizar os dados!'); 
                    }
                }
               
            }
        ?>
        <div class="form-group">
            <label>Nome:</label>
            <input type="text" name="nome" required value="<?php echo $_SESSION['nome']; ?>">
        </div><!--From-Group-->
        <div class="form-group">
            <label>Senha:</label>
            <input type="password" name="password" value="<?php echo $_SESSION['password']; ?>" required>
        </div><!--From-Group-->

        <div class="form-group">
            <label>Imagem</label>
            <input type="file" name="imagem">
            <input type="hidden" name="imagem_atual" value="<?php echo $_SESSION['img']; ?>">
        </div><!--Form-Group-->

        <div class="form-group">
            <input type="submit" name="action" value="Atualizar">

        </div><!--Form-Group-->
    </form>


</div><!--Box-Content-->