<?php
    $usuariosOnline = Painel::listarUsuariosOnline();
    $pegarVisitasTotais = MySql::conects()->prepare("SELECT * FROM `tb_admin.visitas` ");
    $pegarVisitasTotais->execute();

    $pegarVisitasTotais = $pegarVisitasTotais->rowCount();

    $pegarVisitasHoje = MySql::conects()->prepare("SELECT * FROM `tb_admin.visitas` WHERE dia = ?");
    $pegarVisitasHoje->execute(array(date('Y-m-d')));

    $pegarVisitasHoje = $pegarVisitasHoje->rowCount();

?>
<div class="box-content left w100">
    <h2><i class="fa fa-home"></i> Painel de Controle - <?php echo NOME_EMPRESA ?></h2>
    <div class="box-metricas">
        <div class="box-metrica-single">
            <div class="metrica-wraper">
                <h2>Usuários Online</h2>
                <p><?php echo count($usuariosOnline) ?></p>
            </div><!--Metrica-Wraper-->
        </div><!--Metrica-Single-->
        <div class="box-metrica-single">
            <div class="metrica-wraper">
                <h2>Total de Visitas</h2>
                <p><?php echo $pegarVisitasTotais; ?></p>
            </div><!--Metrica-Wraper-->
        </div><!--Metrica-Single-->
        <div class="box-metrica-single">
            <div class="metrica-wraper">
                <h2>Visitas Hoje</h2>
                <p><?php echo $pegarVisitasHoje?></p>
            </div><!--Metrica-Wraper-->
        </div><!--Metrica-Single-->
        <div class="clear"></div>
    </div><!-- box-metricas-->
</div><!--Box-Content-->
<div class="box-content left w50">
<h2><i class="fas fa-globe"></i> Usuários Online </h2>
    <div class="table-responsive">
        <div class="row">
            <div class="col">
                <span>IP</span>
            </div><!--Col-->
            <div class="col">
                <span>Ultima Ação</span>
            </div><!--Col-->
            <div class="clear"></div><!--Clear-->
        </div><!--Row-->
        <?php 
            foreach($usuariosOnline as $key => $value){

        ?>
        <div class="row">
            <div class="col">
                <span><?php echo $value ['ip'] ?></span>
            </div><!--Col-->
            <div class="col">
                <span><?php echo date('d/m/Y H:i:s',strtotime($value['ultima_acao']))?></span>
            </div><!--Col-->
            <div class="clear"></div><!--Clear-->
        </div><!--Row-->
        <?php } ?>
    </div><!--table-->
</div><!--box-content-->

<div class="box-content right w50">
<h2><i class="fas fa-globe"></i> Usuários do Painel </h2>
    <div class="table-responsive">
        <div class="row">
            <div class="col">
                <span>Nome</span>
            </div><!--Col-->
            <div class="col">
                <span>Cargo</span>
            </div><!--Col-->
            <div class="clear"></div><!--Clear-->
        </div><!--Row-->
        <?php 
            $usuariosPainel = MySql::conects()->prepare("SELECT * FROM `tb_admin.users`");
            $usuariosPainel->execute();
            $usuariosPainel = $usuariosPainel->fetchAll();
            foreach($usuariosPainel as $key => $value){

        ?>
        <div class="row">
            <div class="col">
                <span><?php echo $value ['user'] ?></span>
            </div><!--Col-->
            <div class="col">
                <span><?php echo catchCargo($value['cargo']); ?></span>
            </div><!--Col-->
            <div class="clear"></div><!--Clear-->
        </div><!--Row-->
        <?php } ?>
    </div><!--table-->
</div><!--box-content-->

<div class="clear"></div><!--Clear-->