<?php 
    if(isset($_GET['excluir'])){
        $idExcluir = intval($_GET['excluir']);
        Painel::deletar('tb_site.servicos',$idExcluir);
        Painel::redirect(INCLUDE_PATH_PAINEL.'listar-servico');
    }else if(isset($_GET['order']) && isset($_GET['id'])){
        Painel::orderItem('tb_site.servicos',$_GET['order'],$_GET['id']);
    }

    $paginaAtual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
    $porPagina = 4;
    $servicos = Painel::selectAll('tb_site.servicos',($paginaAtual -1) * $porPagina,$porPagina);
    

?>
<div class="box-content">
    <h2><i class="fas fa-concierge-bell"></i> Serviços Cadastrados</h2> 
    <div class="wraper-table">
    <table>
        <tr> 
            <td><i class="fas fa-signature"></i>Serviço</td>
            <td>Editar</td>
            <td>Deletar</td>
            <td>UP</td>
            <td>DOWN</td>
        </tr>

        <?php 
            foreach ($servicos as $key => $value){
        
        ?>

        <tr> 
            <td><?php echo $value['servico']; ?></td>
            <td><a class="btn edit" href="<?php echo INCLUDE_PATH_PAINEL ?>editar-servico?id=<?php echo $value['id']; ?>"><i class="fas fa-edit"></i> Editar</td>
            <td><a actionBtn="delete" class="btn delete" href="<?php echo INCLUDE_PATH_PAINEL ?>listar-servico?excluir=<?php echo $value ['id']; ?>"><i class="fas fa-trash-alt"></i> Excluir</td>
            <td><a class="btn order" href="<?php INCLUDE_PATH_PAINEL ?>listar-servico?order=up&id=<?php echo $value['id'] ?>"><i class="fa fa-angle-up"></a></td>
            <td><a class="btn order" href="<?php INCLUDE_PATH_PAINEL ?>listar-servico?order=down&id=<?php echo $value['id'] ?>"><i class="fa fa-angle-down"></a></td>
        </tr>   
        <?php } ?>
    </table>
    </div><!--Wraper-->

    <div class="paginacao">
        <?php 
            $totalPaginas = ceil(count(Painel::selectAll('tb_site.servicos')) / $porPagina);
            for($i = 1; $i <= $totalPaginas; $i++){
                if($i == $paginaAtual)
                    echo '<a class="page-selected" href="'.INCLUDE_PATH_PAINEL.'listar-servico?pagina='.$i.'">'.$i.'</a>';
                else
                    echo '<a href="'.INCLUDE_PATH_PAINEL.'listar-servico?pagina='.$i.'">'.$i.'</a>';

            }
            
        ?>
    </div><!--paginação-->
</div><!--Box-Content-->
