<div class="box-content">

    <?php Painel::alert('erro','Você não tem permissão para acessar essa página!'); ?>

</div><!--Box-content-->