<?php
    if(isset($_GET['loggout'])){
        Painel::loggout();
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
        <meta name="author" content="Rodolfo Augusto">
        <meta name="description" content="Página de Login">
        <link href="<?php echo INCLUDE_PATH; ?>css/fontawesome.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/fontawesome.min.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/solid.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Gotu&display=swap" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH_PAINEL?>css/estilo.css" rel="stylesheet">
        <meta name="keywords" content="Login mydev, login mycodedev, login my code, Web Development, Desenvolvimento Web">
        <title>Painel de Controle</title>
    </head>
    <body>
    <div class="menu">
        <div class="menu-wraper">
        <div class="user-box">
            <?php 
                if($_SESSION['img'] == ''){
            ?>
                <div class="user-avatar">
                    <i class="fa fa-user"></i>
                </div><!--User-Avatar-->
            <?php }else{ ?>
                <div class="image-user">
                    <img src="<?php echo INCLUDE_PATH_PAINEL ?>uploads/<?php echo $_SESSION['img'];?>" />
                </div><!--User-Avatar-->
            <?php } ?>
            <div class="user-name">
                <p><?php echo $_SESSION['nome']; ?></p>
                <p><?php echo catchCargo($_SESSION['cargo']); ?></p>
            </div><!--UserName-->
        </div><!--USER-BOX-->
        <div class="itens-menu">
                <h2>Cadastro</h2>
                <a <?php selecionadoMenu('cadastrar-depoimento'); ?> href="<?php echo INCLUDE_PATH_PAINEL ?>cadastrar-depoimento">Cadastrar Depoimento</a>
                <a <?php selecionadoMenu('cadastrar-servico'); ?> href="<?php echo INCLUDE_PATH_PAINEL ?>cadastrar-servico">Cadastrar Serviço</a>
                <a <?php selecionadoMenu('cadastrar-slides'); ?> href="<?php echo INCLUDE_PATH_PAINEL ?>cadastrar-slides">Cadastrar Slides</a>
                <h2>Gestão</h2>
                <a <?php selecionadoMenu('listar-depoimento'); ?> href="<?php echo INCLUDE_PATH_PAINEL ?>listar-depoimento">Listar Depoimentos</a>
                <a <?php selecionadoMenu('listar-servico'); ?> href="<?php echo INCLUDE_PATH_PAINEL ?>listar-servico">Listar Serviços</a>
                <a <?php selecionadoMenu('listar-slides'); ?> href="<?php echo INCLUDE_PATH_PAINEL ?>listar-slides">Listar Slides</a>
                <h2>Administração do Painel</h2>
                <a <?php selecionadoMenu('editar-usuario'); ?> href="<?php echo INCLUDE_PATH_PAINEL?>editar-usuario">Editar Usuário</a>
                <a <?php selecionadoMenu('adicionar-usuario'); ?> <?php verificaPermissaoMenu(2); ?> href="<?php echo INCLUDE_PATH_PAINEL ?>adicionar-usuario">Adicionar Usuários</a>
                <h2>Configuração Geral</h2>
                <a <?php selecionadoMenu('editar-site'); ?> href="">Editar Site</a>
        </div><!-- itens menu -->
        </div><!--Menu-Wraper-->
    </div><!--MENU-->

        <header>
        <div class="center">
            <div class="menu-btn">
                <i class="fa fa-bars"></i>
            </div><!--menu-btn-->
            <div class="loggout">
                <a href="<?php echo INCLUDE_PATH_PAINEL; ?>"> <i class="fas fa-home"></i> <span>Página Inicial</span></a>
                <a href="<?php echo INCLUDE_PATH_PAINEL; ?>?loggout"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a>
            </div><!--Loggout-->

            <div class="clear"></div><!--Clear-->
        </div><!--Center-->
        </header> 

        <div class="content">
            <?php Painel::CarregarPagina(); ?>

                    
        </div><!--Content-->
    <script src="<?php echo INCLUDE_PATH ?>js/jquery.js"></script>
    <script src="<?php echo INCLUDE_PATH_PAINEL ?>js/jquery.mask.js"></script>
    <script src="<?php echo INCLUDE_PATH_PAINEL ?>js/main.js"></script>
    </body>
    </html>