<?php   
    if(isset($_COOKIE['lembrar'])){
        $user = $_COOKIE['user'];
        $password = $_COOKIE['password'];
        $sql = MySql::conects()->prepare("SELECT * FROM `tb_admin.users` WHERE user = ? AND password = ?");
        $sql->execute(array($user,$password));
        if($sql->rowCount() == 1){
            $info = $sql->fetch();
            $_SESSION['login'] = true;
            $_SESSION['user'] = $user;
            $_SESSION['password'] = $password;
            $_SESSION['cargo'] = $info['cargo'];
            $_SESSION['nome'] = $info['nome'];
            $_SESSION['img'] = $info['img'];
            header('Location: '.INCLUDE_PATH_PAINEL);
            die();
        }
    }


?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
        <meta name="author" content="Rodolfo Augusto">
        <meta name="description" content="Página de Login">
        <link href="<?php echo INCLUDE_PATH; ?>css/fontawesome.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/fontawesome.min.css" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH; ?>css/solid.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Gotu&display=swap" rel="stylesheet">
        <link href="<?php echo INCLUDE_PATH_PAINEL?>css/estilo.css" rel="stylesheet">
        <meta name="keywords" content="Login mydev, login mycodedev, login my code, Web Development, Desenvolvimento Web">
        <title>Painel de Controle</title>
    </head>
    <body>
        <div class="box-login">
            <?php 
                if(isset($_POST['action'])){
                    $user = $_POST['user'];
                    $password = $_POST['password'];
                    $sql = MySql::conects()->prepare("SELECT * FROM `tb_admin.users` WHERE user = ? AND password = ?");
                    $sql->execute(array($user,$password));
                    if($sql->rowCount() == 1){
                        $info = $sql->fetch();
                        //Logamos com Sucesso.
                        $_SESSION['login'] = true;
                        $_SESSION['user'] = $user;
                        $_SESSION['password'] = $password;
                        $_SESSION['cargo'] = $info['cargo'];
                        $_SESSION['nome'] = $info['nome'];
                        $_SESSION['img'] = $info['img'];
                        if(isset($_POST['lembrar'])){
                            setcookie('lembrar',true,time()+(60*60*24),'/');
                            setcookie('user',$user,time()+(60*60*24),'/');
                            setcookie('password',$password,time()+(60*60*24),'/');
                        }
                        header('Location: '.INCLUDE_PATH_PAINEL);
                        die();
                    }else{
                        //falhou
                        echo '<div class="erro-box"><i class="fas fa-exclamation-triangle"></i> Usuário ou Senha incorretos!</div>';
                    }
                }       
            ?>
            <h2>Login</h2>
            <form method="post">
                <input type="text" name="user" placeholder="Login" required>
                <input type="password" name="password" placeholder="Senha" required>
                <div class="form-group-login">
                    <input type="submit" name="action" value="Logar">
                </div><!--Form-group-login-->
                <div class="form-group-login">
                    <label>Lembrar-me</label>
                    <input type="checkbox" name="lembrar">
                </div><!--Form-group-login-->
                
            </form>
        </div><!--Box-Login-->

    </body>









</html>