<div class="w33 left box-especialidade">
                    <h3><i class="fab fa-html5"></i></h3>
                    <h4>HTML5</h4>
                    <p>HTML5 (Hypertext Markup Language, versão 5) é uma linguagem de marcação para a World Wide Web e é uma tecnologia chave da Internet, originalmente proposto pelo Software Opera. 
                    É a quinta versão da linguagem HTML. Esta nova versão traz consigo importantes mudanças quanto ao papel do HTML no mundo da Web, através de novas funcionalidades como semântica e acessibilidade. Possibilita o uso de novos recursos antes possíveis apenas com a aplicação de outras tecnologias.</p>
                </div><!-- BOX ESPECIALIDADE -->
                <div class="w33 left box-especialidade">
                    <h3><i class="fab fa-css3"></i></h3>
                    <h4>CSS3</h4>
                    <p>O CSS3 é extremamente capaz de construir animações que impressionam o mais avançado desenvolvedor web, tanto em 2 como em 3 dimensões. Os mais comuns são os efeitos de rotação, movimento e transição.
                    Existem, na web, empresas fazendo propaganda utilizando a criatividade e o poder dessa nova era de estilos. CSS3 é a terceira mais nova versão das famosas Cascading Style Sheets (ou simplesmente CSS) pela qual se define estilos para um projeto web (página de internet), com CSS podemos criar estilos únicos</p>
                </div><!-- BOX ESPECIALIDADE -->
                <div class="w33 left box-especialidade">
                    <h3><i class="fab fa-js-square"></i></h3>
                    <h4>JavaScript</h4>
                    <p>JavaScript é uma linguagem de programação criada em 1995 por Brendan Eich enquanto trabalhava na Netscape Communications Corporation. Originalmente projetada para rodar no Netscape Navigator, ela tinha o propósito de oferecer aos desenvolvedores formas de tornar determinados processos de páginas web mais dinâmicos. Depois de seu lançamento, a Microsoft portou a linguagem para seu navegador, o que ajudou a consolidar a linguagem e torná-la uma das tecnologias mais importantes e utilizadas na internet.</p>
                </div><!-- BOX ESPECIALIDADE -->



    box-especialidade{
    margin: 40px 0;
    padding: 0 30px;
    text-align: center;
}

/**Icones na H3**/
.box-especialidade h3{
    margin-bottom: 5px;
    color: #1577B7;
    font-size: 40px;
}

.box-especialidade h4{
    font-size: 30px;
    font-weight: 300;
    color:#282828;
}

.box-especialidade p{
    font-size: 15px;
    color: #282828;
    margin-top: 10px;
    text-align: justify;
}


@
.box-especialidade{
        padding: 40px 20px;
        margin:0;
    }

    .box-especialidade{
        padding: 40px 20px;
        margin:0;
    }




<!--SESSÃO AUTOR-->
<section class="autor">
        <div class="center">
            <div class="box-autor">
                <h2><u>Rodolfo Augusto</u></h2>
                <p>Desenvolvedor FullStack, trabalho com as mais conhecidas lingaguens e ferramentas do mercado, criador e responsável pela DevCodar Development, busco entregar aos meus clientes uma experiência completa dos melhores sistemas atuais.
                Trabalhando de forma eficiente e coesa, prezo a segurança e desempenho de qualquer sistema desenvolvido.
                Utilizando sempre as melhores estrátegias de marketing e SEO, criando assim oportunidades para o contratante expandir sua empresa e serviços.
                Eai, você está pronto para uma nova jornada em seus negócios? Entre em <a class="linkcontato" href="<?php echo INCLUDE_PATH; ?>contato">contato</a>.  <i class="far fa-smile-wink"></i></p>
                <img class="autorimg" src="<?php echo INCLUDE_PATH; ?>images/rof.jpg" />
            </div>
        </div><!--Center-->
        </section>
        </section>
        

        .box-autor{
    margin-top: 20px;
    position: relative;
    text-align: center;

}

.box-autor h2{
    font-weight: normal;
    font-size: 35px;
    margin-top: 30px;
}

.box-autor p {
    font-family: 'Roboto', sans-serif;
    font-weight: normal;
    line-height: 40px;
    font-size: 18px;
    margin-top: 15px;
    letter-spacing: 3px;
    text-align: center;

}

.autorimg{
    margin: 30px 0;
    width: 200px;
    height:200px;
    border-radius: 50%;
    position: relative;
    
}