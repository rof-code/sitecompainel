<section class="banner-container">
        <div style="background-image: url('<?php echo INCLUDE_PATH; ?>images/slide1.jpg');" class="banner-single" title="Desenvolva com a DevCodar!" alt="DevCodar Desenvolvimento de Sistemas"></div><!-- banner single -->
        <div style="background-image: url('<?php echo INCLUDE_PATH; ?>images/slide2.jpg');" class="banner-single" title="Crição de Sites por DevCodar" alt="DevCodar Website"></div><!-- banner single -->
        <div style="background-image: url('<?php echo INCLUDE_PATH; ?>images/slide3.jpg');" class="banner-single"></div><!-- banner single -->
        <div class="overlay"></div>
            <div class="center"><!-- DIV CENTER -->
            <form method="post" action="">
                <h2>Digite seu melhor e-mail</h2>
                <input type="email" name="email" required />
                <input type="hidden" name="identificador" value="form_home" />
                <input type="submit" name="acao" value="Cadastrar">
            </form>
            </div><!-- DIV CENTER -->
            <div class="bullets">
            </div><!--Bullets-->
        </section><!--Banner Principal -->

        <section class="texto-chamada">
            <div class="center">
            <i class="fas fa-code"></i>
                <h2>Criador e responsável pela <b>DevCodar</b></h2>
                
            </div><!--Center-->
        </section><!--Texto-chamada-->

       <!--Sessao Autor -->
       <section class="autor">
           <div class="center">
        <div class="w100-img">
            <img class="imgat" src="<?php echo INCLUDE_PATH; ?>images/rof.jpg" />
        </div><!--w100-->
        </div><!--Center-->
        <div class="center">
            <div class="w100">
            <div class="container2">
            <h2>Rodolfo Augusto</h2>
            <p>Desenvolvedor FullStack, trabalho com as mais conhecidas lingaguens e ferramentas do mercado, criador e responsável pela DevCodar Development, busco entregar aos meus clientes uma experiência completa dos melhores sistemas atuais.<br>
            Trabalhando de forma eficiente e coesa, prezo a segurança e desempenho de qualquer sistema desenvolvido.
            Utilizando sempre as melhores estrátegias de marketing e SEO, criando assim oportunidades para o contratante expandir sua empresa e serviços. <br>
            Eai, você está pronto para uma nova jornada em seus negócios? <i class="far fa-smile-wink"></i></p>
            </div><!--w50 left-->
            </div>
        <div class="clear"></div>
        </div>
       </section>








        <!--Sessao Autor -->
        <section class="especialidades">
            <div class="container">
            <div class="center">
            <h2 class="title">Especialidades</h2>

                <div class="container-single">
                    <div class="icon-round"><i class="fab fa-html5"></i></div><div class="text-descricao"><h2>HTML5</h2><p>HTML5 é uma linguagem de marcação e é uma tecnologia chave da Internet, sem ela não construimos site algum.</p></div>
                </div><!--Container-Single-->

                <div class="container-single">
                    <div class="icon-round"><i class="fab fa-css3-alt"></i></div><div class="text-descricao"><h2>CSS3</h2><p>O CSS3 é extremamente capaz de construir animações que impressionam o mais avançado desenvolvedor web.</p></div>
                </div><!--Container-Single-->

                <div class="container-single">
                    <div class="icon-round"><i class="fab fa-js"></i></div><div class="text-descricao"><h2>JavaScript</h2><p>Lingaguem de programação usada desde a criação de sites até desenvolvimento de aplicativos mobile.</p></div>
                </div><!--Container-Single-->

                <div class="container-single">
                    <div class="icon-round"><i class="fab fa-php"></i></div><div class="text-descricao"><h2>PHP</h2><p>Lingaguem de programação que compõe a maior parte da internet, usada para desenvolvimento back-end.</p></div>
                </div><!--Container-Single-->

                <div class="container-single">
                    <div class="icon-round"><i class="fab fa-react"></i></div><div class="text-descricao"><h2>React</h2><p>Biblioteca JavaScript amplamente usada pelos desenvolvedores atuais para criação de apps mobile.</p></div>
                </div><!--Container-Single-->

                <div class="container-single">
                    <div class="icon-round"><i class="fab fa-node-js"></i></div><div class="text-descricao"><h2>Node.JS</h2><p>Node.js é um interpretador de JavaScript assíncrono com código aberto orientado a eventos.</p></div>
                </div><!--Container-Single-->

                <div class="clear"></div>
            </div><!-- DIV CENTER -->
            </div><!--Container--> 
        </section><!-- ESPECIALIDADES -->

        <section class="texto-chamada">
            <div class="center">
            <i class="fab fa-cloudscale"></i>
                <h2>Alavanque de uma vez o seu <b>negócio!</b></h2>
                <p>Temos as melhores ferramentas para te fazer crescer.</p>
                
            </div><!--Center-->
        </section><!--Texto-chamada-->

        <section id="produtos" class="cards">
          <div class="container">
              <div class="card-single">
                  <img src="images/pr1.jpg" alt="Criação de sites Valinhos/SP">
                  <h3>Criamos seu e-commerce</h3>
                  <p>Criamos a sua loja virtual, para que você expanda seus negócios!</p>
              </div>
            
              <div class="card-single">
                <img src="images/pr3.jpg" alt="Marketing Digital Valinhos">
                <h3>Marketing e SEO</h3>
                <p>Estruturamos todos os projetos para máximo engajamento.</p>
             </div>

              <div class="card-single">
                <img src="images/pr2.jpg" alt="Desenvolvedor web Valinhos São Paulo">
                <h3>Projetos Responsíveis</h3>
                <p>Tudo para melhor experiência do usuário independente do dispositivo!</p>
            </div>
            
              <div class="clear"></div><!--clear-->
          </div>
      </section>

        <section class="extras">
            <div class="center">
            <div id="depoimentos" class="w50 left depoimentos-container">
                <h2 class="title">Depoimentos</h2>
                <?php     
                    $sql = MySql::conects()->prepare("SELECT * FROM `tb_site.depoimentos`  ORDER BY order_id ASC LIMIT 3");
                    $sql->execute();
                    $depoimentos = $sql->fetchAll();
                    foreach($depoimentos as $key => $value){
                ?>
                <div class="depoimento-single">
                    <p class="depoimento-descricao"><?php echo $value['depoimento']; ?></p>
                    <p class="nome-autor"><?php echo $value['nome']; ?> - <?php echo $value['data']; ?></p>
                </div><!-- DEPOIMENTO SINGLE -->
                <?php } ?>
                </div><!-- W50 -->
                <div id="servicos" class="w50 left servicos-container">
                <h2 class="title">Serviços</h2>
                <div class="servicos">
                <ul>
                    <li>Criação de Sites de alta performace, utilizando técnicas de Desing Responsivo (sites que rodam perfeitamente tanto em computadores como em Smartphones e Tablets.)
                    Desenvolvidos com as melhores ferramentas e com máxima fluídez e segurança.</li>
                    <li>Criação de Aplicativos Mobile, Android e IOS, usando React. Aplicativos de pequeno e médio porte para você e sua empresa expandariem seus negócios. </li>
                    <li>Criação de Softwares e Sistemas, em parceria com outros Desenvolvedores, Engenheiros de Software, Analistas de Banco de Dados e Designers, buscamos entregar a melhor experiência em Software Development. </li>
                </ul>
                </div><!-- Serviços -->        
                </div><!-- W50 -->
                <div class="clear"></div><!--CLEAR-->
            </div><!-- DIV CENTER -->
        </section><!-- EXTRAS -->