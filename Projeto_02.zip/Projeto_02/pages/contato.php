<div id="map"></div>
<div class="contato-container">
    <div class="center">
        <form method="post" action="">
            <input required type="text" name="nome" placeholder="Nome...">
            <div></div>
            <input required type="text" name="email" placeholder="E-mail...">
            <div></div>
            <input required type="text" name="telefone" placeholder="Telefone...">
            <div></div>
            <textarea required placeholder="Digite sua mensagem." name="mensagem"></textarea>
            <div></div>
            <input type="hidden" name="identificador" value="form_contato">
            <input type="submit" name="acao" value="Enviar">
        </form>
    </div><!--Center-->
</div><!--Contato-Container-->