<section class="erro-404">
    <div class="center">
        <h2><i style="padding: 0 10px;" class="fa fa-times"></i>Página não encontrada!</h2>
        <p>Deseja voltar para a <a href="<?php echo  INCLUDE_PATH; ?>"> página inicial?
    </div><!-- CENTER -->
</section>