$(function(){

    var atual = -1; 
    var maximo = $('.box-especialidade').length -1;
    var timer;
    var delayAnimate = 1;
    
    executeAnimate();
    function executeAnimate(){
        $('.box-especialidade').hide();  
        timer = setInterval(animateLogic,delayAnimate*1000);

        function animateLogic(){
            atual++;
            if(atual > maximo){
                clearInterval(timer);
                return false;
            }
            $('.box-especialidade').eq(atual).fadeIn();
    
        }
            
    }
})